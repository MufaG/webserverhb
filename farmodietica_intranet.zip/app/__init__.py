from flask import Flask
from .config import load_config
from .auth import auth_bp, login_required
from .blueprints.core import core_bp

def create_app():
    app = Flask(__name__)
    load_config(app)

    # Blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(core_bp)

    # Register a simple health endpoint (no auth) for Nginx checks
    @app.get("/healthz")
    def healthz():
        return {"status": "ok"}, 200

    return app
