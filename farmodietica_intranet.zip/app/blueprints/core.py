from flask import Blueprint, render_template
from ..auth import login_required

core_bp = Blueprint("core", __name__)

@core_bp.route("/")
@login_required
def dashboard():
    return render_template("dashboard.html")

@core_bp.route("/inventario")
@login_required
def inventario():
    return render_template("inventario.html")

@core_bp.route("/infraestrutura")
@login_required
def infraestrutura():
    return render_template("infraestrutura.html")

@core_bp.route("/seguranca")
@login_required
def seguranca():
    return render_template("seguranca.html")

@core_bp.route("/documentacao")
@login_required
def documentacao():
    return render_template("documentacao.html")

@core_bp.route("/scripts")
@login_required
def scripts():
    return render_template("scripts.html")

@core_bp.route("/estado")
@login_required
def estado():
    return render_template("estado.html")
