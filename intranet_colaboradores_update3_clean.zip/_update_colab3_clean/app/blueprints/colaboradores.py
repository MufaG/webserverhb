
from flask import Blueprint, render_template, request, jsonify, send_file, redirect, current_app, session
import os, io, json, datetime

colab_bp = Blueprint("colaboradores", __name__, url_prefix="/colaboradores")

def _data_path(filename):
    base = os.path.abspath(os.path.join(current_app.root_path, "..", "data"))
    return os.path.join(base, filename)

def _load_funcoes():
    fp = _data_path("funcoes.json")
    if not os.path.exists(fp):
        return {}
    with open(fp, "r", encoding="utf-8") as f:
        raw = json.load(f)
    if isinstance(raw, list):
        result = {}
        for row in raw:
            dep = row.get("departamento") or row.get("Departamento") or "Outros"
            fun = row.get("nome") or row.get("Função") or row.get("funcao") or "Função"
            result.setdefault(dep, []).append(fun)
        for k, v in result.items():
            result[k] = sorted(list(dict.fromkeys(v)))
        return result
    elif isinstance(raw, dict):
        return {dep: sorted(list(d.keys())) for dep, d in raw.items()}
    return {}

@colab_bp.route("/", methods=["GET"])
def view():
    role = session.get("role", "USER")
    funcoes = _load_funcoes()
    return render_template("colaboradores/preencher.html", funcoes=funcoes, user_role=role)

@colab_bp.route("/funcs", methods=["GET"])
def funcs():
    return jsonify(_load_funcoes())

@colab_bp.route("/pdf", methods=["POST"])
def pdf():
    data = request.form.to_dict()
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfgen import canvas
        from reportlab.lib.units import cm
        buf = io.BytesIO()
        c = canvas.Canvas(buf, pagesize=A4)
        w, h = A4
        y = h - 2*cm
        c.setFont("Helvetica-Bold", 14); c.drawString(2*cm, y, "Checklist de Onboarding"); y -= 1*cm
        c.setFont("Helvetica", 11)
        for k, v in data.items():
            line = f"{k}: {v}"
            if y < 2*cm: c.showPage(); y = h - 2*cm; c.setFont("Helvetica", 11)
            c.drawString(2*cm, y, line); y -= 0.7*cm
        c.showPage(); c.save(); buf.seek(0)
        fname = f"onboarding_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        return send_file(buf, as_attachment=True, download_name=fname, mimetype="application/pdf")
    except Exception as e:
        txt = io.StringIO()
        txt.write("Checklist de Onboarding\n\n")
        for k, v in data.items():
            txt.write(f"{k}: {v}\n")
        buf = io.BytesIO(txt.getvalue().encode("utf-8"))
        fname = f"onboarding_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        return send_file(buf, as_attachment=True, download_name=fname, mimetype="text/plain; charset=utf-8")

@colab_bp.route("/mailto", methods=["GET"])
def mailto():
    to = "hugobastos@farmodietica.com"
    subject = "Checklist de Onboarding"
    body = ("Olá,%0D%0A%0D%0A"
            "Segue em anexo a checklist de onboarding do novo colaborador.%0D%0A"
            "Obrigado.")
    url = f"mailto:{to}?subject={subject}&body={body}"
    return redirect(url)
