
Instalação do módulo 'Colaboradores':

1) Descompactar o pacote na VM:
   unzip -o intranet_colaboradores_update.zip -d /opt/farmodietica_intranet/_update_colab

2) Copiar ficheiros para o projeto:
   sudo cp -r /opt/farmodietica_intranet/_update_colab/app/blueprints/colaboradores.py /opt/farmodietica_intranet/app/blueprints/
   sudo cp -r /opt/farmodietica_intranet/_update_colab/app/templates/colaboradores /opt/farmodietica_intranet/app/templates/
   sudo cp -r /opt/farmodietica_intranet/_update_colab/data /opt/farmodietica_intranet/
   sudo cp /opt/farmodietica_intranet/_update_colab/import_funcoes_from_excel.py /opt/farmodietica_intranet/
   sudo chown -R intranet:intranet /opt/farmodietica_intranet/app /opt/farmodietica_intranet/data /opt/farmodietica_intranet/import_funcoes_from_excel.py

3) Editar app/__init__.py e registar o blueprint:
   from .blueprints.colaboradores import colab_bp
   app.register_blueprint(colab_bp)

4) Colocar o link no topo do menu (app/templates/base.html):
   <a class="block p-2 rounded hover:bg-gray-100" href="{{ url_for('colab.index') }}">👥 Colaboradores</a>

5) Instalar openpyxl (para importar funções do Excel):
   sudo -u intranet /opt/farmodietica_intranet/venv/bin/pip install openpyxl

6) Gerar funcoes.json a partir do Excel (1ª aba):
   sudo -u intranet /opt/farmodietica_intranet/venv/bin/python /opt/farmodietica_intranet/import_funcoes_from_excel.py      /opt/farmodietica_intranet/data/Assinaturas.xlsx      /opt/farmodietica_intranet/data/funcoes.json

7) Reiniciar:
   sudo systemctl restart intranet

Aceder: http://10.77.0.206/colaboradores
