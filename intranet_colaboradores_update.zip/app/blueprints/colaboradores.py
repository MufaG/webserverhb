
from flask import Blueprint, render_template, request, jsonify
from ..auth import role_required
import os, json

colab_bp = Blueprint("colab", __name__, url_prefix="/colaboradores")

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
DATA_DIR = os.path.join(BASE_DIR, "data")
FUNCOES_FILE = os.path.join(DATA_DIR, "funcoes.json")
CHECKLISTS_FILE = os.path.join(DATA_DIR, "checklists.json")
EQUIP_FILE = os.path.join(DATA_DIR, "equipamentos.json")
ONBOARD_FILE = os.path.join(DATA_DIR, "onboarding.json")

def _load_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default

def _save_json(path, data):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)

@colab_bp.route("/")
@role_required(["admin", "tecnico"])
def index():
    funcoes = _load_json(FUNCOES_FILE, [])
    return render_template("colaboradores/index.html", funcoes=funcoes)

@colab_bp.route("/editar")
@role_required(["admin", "tecnico"])
def editar():
    funcoes = _load_json(FUNCOES_FILE, [])
    return render_template("colaboradores/editar.html", funcoes=funcoes)

@colab_bp.route("/equipamentos")
@role_required(["admin", "tecnico"])
def equipamentos():
    funcoes = _load_json(FUNCOES_FILE, [])
    return render_template("colaboradores/equipamentos.html", funcoes=funcoes)

@colab_bp.route("/preencher")
@role_required(["admin", "tecnico"])
def preencher():
    funcoes = _load_json(FUNCOES_FILE, [])
    return render_template("colaboradores/preencher.html", funcoes=funcoes)

@colab_bp.get("/api/funcoes")
@role_required(["admin","tecnico"])
def api_funcoes():
    return jsonify(_load_json(FUNCOES_FILE, []))

@colab_bp.get("/api/checklists")
@role_required(["admin","tecnico"])
def api_get_checklist():
    func = request.args.get("func")
    cl = _load_json(CHECKLISTS_FILE, {})
    return jsonify(cl.get(func, []))

@colab_bp.post("/api/checklists")
@role_required(["admin","tecnico"])
def api_set_checklist():
    payload = request.get_json(force=True, silent=True) or {}
    func = payload.get("func")
    tasks = payload.get("tasks", [])
    if not func:
        return jsonify({"ok": False, "error": "função em falta"}), 400
    cl = _load_json(CHECKLISTS_FILE, {})
    cl[func] = [str(t).strip() for t in tasks if str(t).strip()]
    _save_json(CHECKLISTS_FILE, cl)
    return jsonify({"ok": True})

@colab_bp.get("/api/equipamentos")
@role_required(["admin","tecnico"])
def api_get_equip():
    func = request.args.get("func")
    eq = _load_json(EQUIP_FILE, {})
    return jsonify(eq.get(func, []))

@colab_bp.post("/api/equipamentos")
@role_required(["admin","tecnico"])
def api_set_equip():
    payload = request.get_json(force=True, silent=True) or {}
    func = payload.get("func")
    items = payload.get("items", [])
    if not func:
        return jsonify({"ok": False, "error": "função em falta"}), 400
    eq = _load_json(EQUIP_FILE, {})
    eq[func] = [str(i).strip() for i in items if str(i).strip()]
    _save_json(EQUIP_FILE, eq)
    return jsonify({"ok": True})

@colab_bp.post("/api/onboarding")
@role_required(["admin","tecnico"])
def api_save_onboarding():
    payload = request.get_json(force=True, silent=True) or {}
    required = ["colaborador","funcao","checklist","equipamentos"]
    if not all(k in payload for k in required):
        return jsonify({"ok": False, "error": "dados incompletos"}), 400
    ob = _load_json(ONBOARD_FILE, [])
    ob.append(payload)
    _save_json(ONBOARD_FILE, ob)
    return jsonify({"ok": True})
