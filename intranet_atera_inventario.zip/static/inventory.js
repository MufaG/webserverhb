const btn = document.getElementById('btn-refresh');
const spin = document.getElementById('spin');
const last = document.getElementById('last-refresh');

async function refreshNow() {
  spin.style.display = 'inline-block';
  btn.disabled = true;
  try {
    const res = await fetch('/inventario/refresh', {method:'POST'});
    const data = await res.json();
    if (!data.ok) throw new Error(data.error || 'Falha a atualizar');
    // Reload page to show fresh counts
    last.textContent = new Date().toISOString();
    window.location.reload();
  } catch (e) {
    alert('Erro: ' + e.message);
  } finally {
    spin.style.display = 'none';
    btn.disabled = false;
  }
}
btn.addEventListener('click', refreshNow);
