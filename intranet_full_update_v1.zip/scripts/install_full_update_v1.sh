#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/opt/farmodietica_intranet"
UPDATE_DIR="$(pwd)"

if [[ ! -d "$APP_DIR" ]]; then
  echo "❌ Pasta $APP_DIR não existe neste servidor."
  exit 1
fi

cd "$APP_DIR"

# Backup
ts=$(date +%Y%m%d-%H%M%S)
tar czf "/opt/backup_intranet_${ts}.tgz" app data deploy || true
echo "📦 Backup em /opt/backup_intranet_${ts}.tgz"

# Copiar ficheiros
cp -r "$UPDATE_DIR/app/blueprints/colaboradores.py" "$APP_DIR/app/blueprints/"
mkdir -p "$APP_DIR/app/templates/colaboradores"
cp -r "$UPDATE_DIR/app/templates/colaboradores/preencher.html" "$APP_DIR/app/templates/colaboradores/"
mkdir -p "$APP_DIR/data"
cp -n "$UPDATE_DIR/data/checklists.json" "$APP_DIR/data/" || true

# Registar blueprint (idempotente)
if ! grep -q "from app.blueprints.colaboradores import colab_bp" "$APP_DIR/app/__init__.py"; then
  sed -i '1afrom app.blueprints.colaboradores import colab_bp' "$APP_DIR/app/__init__.py"
fi
if ! grep -q "register_blueprint(colab_bp)" "$APP_DIR/app/__init__.py"; then
  sed -i 's/register_blueprint(core_bp)/register_blueprint(core_bp)\n    app.register_blueprint(colab_bp)/' "$APP_DIR/app/__init__.py"
fi

# Injetar item no menu (ADMIN)
awk '
/<nav class=/ && !seenblock {
  print; print "{% set _role = session.get(\"role\") or session.get(\"user_role\") or session.get(\"perfil\") %}";
  seenblock=1; next
}
/👥 Colaboradores/ {printed=1}
{print}
END {
  if (!printed) {
    print "{% if _role == \"ADMIN\" %}<li><a href=\"{{ url_for(\"colaboradores.view\") }}\">👥 Colaboradores</a></li>{% endif %}"
  }
}
' "$APP_DIR/app/templates/base.html" > "$APP_DIR/app/templates/base.html.new" && mv "$APP_DIR/app/templates/base.html.new" "$APP_DIR/app/templates/base.html"

# Permissões e restart
chown -R intranet:intranet "$APP_DIR/app" "$APP_DIR/data"
systemctl restart intranet
echo "✅ Update aplicado. Abra http://10.77.0.206/ (Ctrl+F5)."
