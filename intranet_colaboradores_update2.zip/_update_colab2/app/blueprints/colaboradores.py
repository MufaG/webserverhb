from flask import Blueprint, render_template, request, jsonify
import json, os

colab_bp = Blueprint('colaboradores', __name__, url_prefix='/colaboradores')

DATA_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'data', 'checklists.json')

@colab_bp.route('/')
def index():
    with open(DATA_PATH, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return render_template('colaboradores/preencher.html', data=data)

@colab_bp.route('/get_funcoes', methods=['POST'])
def get_funcoes():
    dept = request.json.get('departamento')
    with open(DATA_PATH, 'r', encoding='utf-8') as f:
        data = json.load(f)
    funcoes = list(data.get(dept, {}).keys())
    return jsonify(funcoes)