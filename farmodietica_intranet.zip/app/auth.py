from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from werkzeug.security import check_password_hash
from functools import wraps
from flask import current_app as app

auth_bp = Blueprint("auth", __name__)

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("auth.login", next=request.path))
        return view(*args, **kwargs)
    return wrapped

@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username","").strip()
        password = request.form.get("password","")
        admin_user = app.config.get("ADMIN_USERNAME")
        admin_hash = app.config.get("ADMIN_PASSWORD_HASH")
        if username == admin_user and admin_hash and check_password_hash(admin_hash, password):
            session["logged_in"] = True
            session["user"] = username
            flash("Login efetuado com sucesso.", "success")
            next_url = request.args.get("next") or url_for("core.dashboard")
            return redirect(next_url)
        flash("Credenciais inválidas.", "danger")
    return render_template("login.html")

@auth_bp.route("/logout")
def logout():
    session.clear()
    flash("Sessão terminada.", "info")
    return redirect(url_for("auth.login"))
