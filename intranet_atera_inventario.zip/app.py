import os
from flask import Flask, render_template, jsonify, Blueprint, request
from dotenv import load_dotenv
from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime
from atera_integration.ingest import init_db, refresh_all, get_summary_counts, get_last_refresh

load_dotenv()

app = Flask(__name__)
app.config['JSON_AS_ASCII'] = False

# --- DB init on startup
init_db()

# --- Blueprint: Inventário
inv_bp = Blueprint('inventario', __name__, url_prefix='/inventario')

@inv_bp.route('/')
def inventory_home():
    counts = get_summary_counts()
    last = get_last_refresh()
    return render_template('inventory.html', counts=counts, last_refresh=last)

@inv_bp.route('/refresh', methods=['POST'])
def inventory_refresh():
    # Trigger manual refresh
    try:
        stats = refresh_all()
        return jsonify({'ok': True, 'stats': stats})
    except Exception as e:
        return jsonify({'ok': False, 'error': str(e)}), 500

app.register_blueprint(inv_bp)

# --- Scheduler (every 6 hours by default)
scheduler = BackgroundScheduler(timezone=os.getenv('TZ', 'Europe/Lisbon'))
def scheduled_refresh():
    try:
        refresh_all()
    except Exception as e:
        # Keep running even if one refresh fails
        print(f"[Scheduler] Refresh failed: {e}")
scheduler.add_job(scheduled_refresh, 'interval', hours=6, id='atera_refresh_every_6h', replace_existing=True)
scheduler.start()

@app.route('/healthz')
def healthz():
    return {'status': 'ok', 'time': datetime.utcnow().isoformat() + 'Z'}

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.getenv('PORT', 5000)))
