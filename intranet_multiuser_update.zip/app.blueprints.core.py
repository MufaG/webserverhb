from flask import Blueprint, render_template
from ..auth import login_required, role_required

core_bp = Blueprint("core", __name__)

@core_bp.route("/")
@login_required
def dashboard():
    return render_template("dashboard.html")

@core_bp.route("/inventario")
@role_required(["admin","tecnico"])
def inventario():
    return render_template("inventario.html")

@core_bp.route("/infraestrutura")
@role_required(["admin","tecnico"])
def infraestrutura():
    return render_template("infraestrutura.html")

@core_bp.route("/seguranca")
@role_required("admin")
def seguranca():
    return render_template("seguranca.html")

@core_bp.route("/documentacao")
@role_required(["admin","tecnico","consultor","coordenador","armazem"])
def documentacao():
    return render_template("documentacao.html")

@core_bp.route("/scripts")
@role_required(["admin","tecnico"])
def scripts():
    return render_template("scripts.html")

@core_bp.route("/estado")
@role_required(["admin","tecnico","consultor","coordenador","armazem"])
def estado():
    return render_template("estado.html")
