import os
from dotenv import load_dotenv

def load_config(app):
    load_dotenv(os.path.join(os.path.dirname(os.path.dirname(__file__)), ".env"), override=False)
    app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "dev_key_change_me")
    app.config["ADMIN_USERNAME"] = os.getenv("ADMIN_USERNAME", "admin")
    app.config["ADMIN_PASSWORD_HASH"] = os.getenv("ADMIN_PASSWORD_HASH", "")
    app.config["BIND_HOST"] = os.getenv("BIND_HOST", "127.0.0.1")
    app.config["BIND_PORT"] = int(os.getenv("BIND_PORT", "8000"))
