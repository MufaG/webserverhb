from app import create_app
app = create_app()

if __name__ == "__main__":
    app.run(host=app.config.get("BIND_HOST","127.0.0.1"), port=app.config.get("BIND_PORT",8000), debug=True)
