Farmodiética Intranet — Full Update v1
======================================

Este pacote consolida o módulo **Colaboradores (Onboarding)** e a integração no menu (apenas ADMIN),
mantendo o restante do teu projeto inalterado.

O que está incluído
-------------------
1) app/blueprints/colaboradores.py
   - Blueprint robusto (aceita vários formatos de funcoes.json)
   - Proteção: apenas ADMIN acede às rotas /colaboradores
   - Endpoints:
       /colaboradores/              → página "Checklist de Onboarding"
       /colaboradores/api/funcoes   → JSON com Departamentos → Funções
2) app/templates/colaboradores/preencher.html
   - Formulário com Departamento → Função (dinâmico), Nome, Email, M365, OneDrive, PHC, NAS
   - Botões: Gerar PDF (se não tiver reportlab, faz download de TXT) e mailto (placeholder)
3) data/checklists.json (base)
   - NÃO substitui funcoes.json; o código usa o funcoes.json existente no servidor
4) scripts/install_full_update_v1.sh
   - Script de instalação automatizada:
     * backup
     * cópia de ficheiros
     * registo do blueprint (idempotente)
     * injeta o item de menu "👥 Colaboradores" apenas para ADMIN (sem depender do nome exacto da chave)
5) docs/CHANGELOG.txt, docs/INSTRUCOES.txt

Requisitos opcionais
--------------------
- Para PDF real (em vez de TXT fallback): instalar reportlab no venv
  sudo -u intranet /opt/farmodietica_intranet/venv/bin/pip install reportlab

Instalação
----------
1) Envia este ZIP para o servidor e descompacta em /opt/farmodietica_intranet/_full_update_v1
2) Corre:
   sudo bash scripts/install_full_update_v1.sh

Depois abre: http://10.77.0.206/colaboradores
