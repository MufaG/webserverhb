#!/usr/bin/env python3
import json, os, sys
from getpass import getpass
from pathlib import Path
from werkzeug.security import generate_password_hash

ROOT = Path(__file__).resolve().parent
USERS_FILE = ROOT / "users.json"

ROLES = ["admin", "tecnico", "consultor", "coordenador", "armazem"]

def load_users():
    if USERS_FILE.exists():
        with open(USERS_FILE, "r") as f:
            return json.load(f)
    return []

def save_users(data):
    tmp = USERS_FILE.with_suffix(".tmp")
    with open(tmp, "w") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, USERS_FILE)

def find_user(data, username):
    for u in data:
        if u.get("username") == username:
            return u
    return None

def add_or_update_user():
    data = load_users()
    username = input("Utilizador: ").strip()
    if not username:
        print("✖ Utilizador inválido")
        sys.exit(1)

    role = input(f"Role ({'/'.join(ROLES)}): ").strip().lower()
    if role not in ROLES:
        print("✖ Role inválida")
        sys.exit(1)

    while True:
        pwd1 = getpass("Password: ")
        pwd2 = getpass("Confirmar password: ")
        if pwd1 != pwd2:
            print("✖ Passwords não coincidem. Tenta de novo.")
            continue
        if len(pwd1) < 8:
            print("✖ Password demasiado curta (mín. 8).")
            continue
        break

    hashv = generate_password_hash(pwd1)

    user = find_user(data, username)
    if user:
        user["password_hash"] = hashv
        user["role"] = role
        print(f"✓ Utilizador atualizado: {username} ({role})")
    else:
        data.append({"username": username, "password_hash": hashv, "role": role})
        print(f"✓ Utilizador criado: {username} ({role})")

    save_users(data)
    print(f"✓ Guardado em {USERS_FILE}")

def remove_user():
    data = load_users()
    username = input("Utilizador a remover: ").strip()
    new_data = [u for u in data if u.get("username") != username]
    if len(new_data) == len(data):
        print("✖ Utilizador não encontrado.")
    else:
        save_users(new_data)
        print(f"✓ Removido: {username}")

def list_users():
    data = load_users()
    if not data:
        print("(vazio)")
        return
    print("Utilizadores:")
    for u in data:
        print(f" - {u.get('username')} [{u.get('role')}]")

def main():
    if len(sys.argv) < 2 or sys.argv[1] not in ["add", "remove", "list"]:
        print("Uso: python3 add_user.py [add|remove|list]")
        sys.exit(1)
    cmd = sys.argv[1]
    if cmd == "add":
        add_or_update_user()
    elif cmd == "remove":
        remove_user()
    elif cmd == "list":
        list_users()

if __name__ == "__main__":
    main()
