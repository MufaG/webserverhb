import os, sqlite3, re, time
from datetime import datetime, timezone
from typing import Dict, Any, List, Tuple
from dotenv import load_dotenv
from .atera_client import AteraClient

load_dotenv()

DB_PATH = os.getenv('INTRANET_DB_PATH', './intranet.db')

# --- DB helpers
def _conn():
    return sqlite3.connect(DB_PATH, detect_types=sqlite3.PARSE_DECLTYPES)

def init_db():
    with _conn() as cx:
        cx.execute('PRAGMA journal_mode=WAL')
        cx.execute('''CREATE TABLE IF NOT EXISTS devices (
            agent_id INTEGER PRIMARY KEY,
            customer_id INTEGER,
            customer_name TEXT,
            hostname TEXT,
            manufacturer TEXT,
            model TEXT,
            os_name TEXT,
            os_edition TEXT,
            os_version TEXT,
            last_seen TEXT,
            updated_at TEXT
        )''')
        cx.execute('''CREATE TABLE IF NOT EXISTS software (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            agent_id INTEGER,
            name TEXT,
            version TEXT,
            publisher TEXT,
            installed_on TEXT,
            updated_at TEXT
        )''')
        cx.execute('''CREATE TABLE IF NOT EXISTS meta (
            k TEXT PRIMARY KEY,
            v TEXT
        )''')

# --- Normalization helpers

def _extract_os_edition(os_name: str) -> str:
    if not os_name:
        return ''
    # Look for common editions
    s = os_name.lower()
    if 'windows 11' in s:
        if 'pro' in s: return 'Windows 11 Pro'
        if 'home' in s: return 'Windows 11 Home'
        return 'Windows 11'
    if 'windows 10' in s:
        if 'pro' in s: return 'Windows 10 Pro'
        if 'home' in s: return 'Windows 10 Home'
        return 'Windows 10'
    if 'windows server' in s: return 'Windows Server'
    if 'macos' in s or 'mac os' in s: return 'macOS'
    if 'ubuntu' in s: return 'Ubuntu'
    if 'debian' in s: return 'Debian'
    return os_name

OFFICE_PATTERNS = [
    r'office\s*365', r'microsoft\s*365', r'office\s*201[69]', r'office\s*202[13]',
    r'office\s*pro\s*plus', r'microsoft\s*office', r'office\s*ltc', r'office\s*ltsc'
]
AV_PATTERNS = [
    r'defender', r'bitdefender', r'eset', r'kaspersky', r'sophos', r'crowdstrike',
    r'sentinelone', r'avast', r'avg', r'trend\s*micro', r'webroot', r'malwarebytes'
]

def _is_office(name: str) -> bool:
    s = (name or '').lower()
    return any(re.search(p, s) for p in OFFICE_PATTERNS)

def _is_av(name: str) -> bool:
    s = (name or '').lower()
    return any(re.search(p, s) for p in AV_PATTERNS)

# --- Pull & Store

def _paginate(fetch_fn, *args, **kwargs):
    page = 1
    while True:
        data = fetch_fn(*args, page=page, **kwargs)
        # Expect Atera pagination wrapper like:
        # {'result': [...], 'totalPages': N, 'page': 1, 'itemsInPage': 50}
        items = data.get('result') or data.get('Result') or data.get('data') or []
        total_pages = data.get('totalPages') or 1
        yield from items
        if page >= total_pages:
            break
        page += 1

def refresh_all() -> Dict[str, Any]:
    init_db()
    client = AteraClient()
    now = datetime.now(timezone.utc).isoformat()
    device_count = 0
    software_rows = 0
    agents = list(_paginate(client.get_agents, items_in_page=50))

    with _conn() as cx:
        # Devices
        for a in agents:
            device_count += 1
            # Attempt to read common fields safely
            agent_id = a.get('AgentID') or a.get('id') or a.get('agentId')
            hostname = a.get('MachineName') or a.get('ComputerName') or a.get('name')
            customer_id = a.get('CustomerID') or a.get('customerId')
            customer_name = a.get('CustomerName') or a.get('customerName')
            manufacturer = a.get('Manufacturer') or a.get('manufacturer')
            model = a.get('Model') or a.get('model')
            os_name = a.get('OperatingSystemName') or a.get('OSName') or a.get('OperatingSystem') or ''
            os_version = a.get('OperatingSystemVersion') or a.get('OSVersion') or ''
            os_edition = _extract_os_edition(os_name)
            last_seen = a.get('LastSeen') or a.get('LastSeenDate') or ''

            cx.execute('''INSERT INTO devices(agent_id, customer_id, customer_name, hostname, manufacturer, model, os_name, os_edition, os_version, last_seen, updated_at)
                          VALUES(?,?,?,?,?,?,?,?,?,?,?)
                          ON CONFLICT(agent_id) DO UPDATE SET
                            customer_id=excluded.customer_id,
                            customer_name=excluded.customer_name,
                            hostname=excluded.hostname,
                            manufacturer=excluded.manufacturer,
                            model=excluded.model,
                            os_name=excluded.os_name,
                            os_edition=excluded.os_edition,
                            os_version=excluded.os_version,
                            last_seen=excluded.last_seen,
                            updated_at=excluded.updated_at
                        ''', (agent_id, customer_id, customer_name, hostname, manufacturer, model, os_name, os_edition, os_version, last_seen, now))

        # Software per agent (only for agents we just got)
        for a in agents:
            agent_id = a.get('AgentID') or a.get('id') or a.get('agentId')
            if not agent_id:
                continue
            sw_list = list(_paginate(lambda **kw: client.get_agent_software(agent_id, **kw), items_in_page=100))
            # Clean old software rows for this agent
            cx.execute('DELETE FROM software WHERE agent_id = ?', (agent_id,))
            for sw in sw_list:
                name = sw.get('Name') or sw.get('DisplayName') or sw.get('name')
                version = sw.get('Version') or sw.get('DisplayVersion') or sw.get('version')
                publisher = sw.get('Publisher') or sw.get('publisher')
                installed_on = sw.get('InstallDate') or sw.get('installDate')
                if not name:
                    continue
                cx.execute('''INSERT INTO software(agent_id, name, version, publisher, installed_on, updated_at)
                              VALUES(?,?,?,?,?,?)''', (agent_id, name, version, publisher, installed_on, now))
                software_rows += 1

        # Meta: last refresh
        cx.execute('REPLACE INTO meta(k, v) VALUES (?,?)', ('last_refresh', now))

    return {'agents': device_count, 'software': software_rows, 'refreshed_at': now}

def _fetch_counts(query: str) -> List[Tuple[str, int]]:
    with _conn() as cx:
        cur = cx.execute(query)
        rows = cur.fetchall()
        return [(row[0] if row[0] else 'Desconhecido', int(row[1])) for row in rows]

def get_summary_counts() -> Dict[str, Any]:
    # Models
    by_model = _fetch_counts('''
        SELECT COALESCE(model, '') as grp, COUNT(*) 
        FROM devices GROUP BY grp ORDER BY COUNT(*) DESC, grp ASC
    ''')
    # OS Editions (Windows 11 Pro/Home, etc.)
    by_os = _fetch_counts('''
        SELECT COALESCE(os_edition, '') as grp, COUNT(*)
        FROM devices GROUP BY grp ORDER BY COUNT(*) DESC, grp ASC
    ''')
    # Office detections via software patterns
    by_office = _fetch_counts('''
        SELECT grp, COUNT(DISTINCT agent_id) FROM (
            SELECT agent_id,
                   CASE
                       WHEN LOWER(name) LIKE '%office 365%' OR LOWER(name) LIKE '%microsoft 365%' THEN 'Microsoft 365 Apps'
                       WHEN LOWER(name) LIKE '%office 2021%' THEN 'Office 2021'
                       WHEN LOWER(name) LIKE '%office 2019%' THEN 'Office 2019'
                       WHEN LOWER(name) LIKE '%office 2016%' THEN 'Office 2016'
                       WHEN LOWER(name) LIKE '%proplus%' THEN 'Office ProPlus'
                       WHEN LOWER(name) LIKE '%office%' THEN 'Microsoft Office (outros)'
                       ELSE 'Sem Office'
                   END AS grp
            FROM software
        ) t GROUP BY grp ORDER BY COUNT(DISTINCT agent_id) DESC, grp ASC
    ''')
    # Antivirus detections
    by_av = _fetch_counts('''
        SELECT grp, COUNT(DISTINCT agent_id) FROM (
            SELECT agent_id,
                   CASE
                       WHEN LOWER(name) LIKE '%defender%' THEN 'Microsoft Defender'
                       WHEN LOWER(name) LIKE '%bitdefender%' THEN 'Bitdefender'
                       WHEN LOWER(name) LIKE '%eset%' THEN 'ESET'
                       WHEN LOWER(name) LIKE '%kaspersky%' THEN 'Kaspersky'
                       WHEN LOWER(name) LIKE '%sophos%' THEN 'Sophos'
                       WHEN LOWER(name) LIKE '%sentinelone%' THEN 'SentinelOne'
                       WHEN LOWER(name) LIKE '%crowdstrike%' THEN 'CrowdStrike'
                       WHEN LOWER(name) LIKE '%avast%' THEN 'Avast'
                       WHEN LOWER(name) LIKE '%avg%' THEN 'AVG'
                       WHEN LOWER(name) LIKE '%trend micro%' THEN 'Trend Micro'
                       WHEN LOWER(name) LIKE '%webroot%' THEN 'Webroot'
                       WHEN LOWER(name) LIKE '%malwarebytes%' THEN 'Malwarebytes'
                       ELSE 'Sem AV detectado'
                   END AS grp
            FROM software
        ) t GROUP BY grp ORDER BY COUNT(DISTINCT agent_id) DESC, grp ASC
    ''')
    return {
        'by_model': by_model,
        'by_os': by_os,
        'by_office': by_office,
        'by_av': by_av,
    }

def get_last_refresh() -> str:
    with _conn() as cx:
        cur = cx.execute('SELECT v FROM meta WHERE k = ?', ('last_refresh',))
        row = cur.fetchone()
        return row[0] if row else ''
