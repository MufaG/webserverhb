#!/usr/bin/env python3
import sys, os, json
from openpyxl import load_workbook

def main():
    if len(sys.argv) < 3:
        print("Uso: python3 import_funcoes_from_excel.py </caminho/Assinaturas.xlsx> </caminho/saida/funcoes.json>")
        sys.exit(1)
    xlsx = sys.argv[1]
    out = sys.argv[2]
    wb = load_workbook(filename=xlsx, data_only=True)
    ws = wb.worksheets[0]
    headers = { (cell.value or '').strip().lower(): cell.column for cell in ws[1] if cell.value }
    dep_col = headers.get('departamento')
    func_col = headers.get('função') or headers.get('funcao')
    if not dep_col or not func_col:
        print("✖ Não encontrei colunas 'Departamento' e 'Função' na primeira linha.")
        sys.exit(2)
    combos = set()
    for row in ws.iter_rows(min_row=2):
        dep = row[dep_col-1].value
        func = row[func_col-1].value
        if dep and func:
            combos.add(f"{dep} - {func}")
    res = sorted(list(combos))
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)
    print(f"✓ Funções exportadas: {len(res)} → {out}")

if __name__ == "__main__":
    main()
