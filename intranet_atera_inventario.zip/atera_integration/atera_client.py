import os
import requests
from urllib.parse import urljoin

class AteraClient:
    def __init__(self, api_key: str = None, base_url: str = None, timeout: int = 30):
        self.api_key = api_key or os.getenv('ATERA_API_KEY')
        if not self.api_key:
            raise ValueError('ATERA_API_KEY não definido (.env)')
        self.base_url = (base_url or os.getenv('ATERA_BASE_URL') or 'https://app.atera.com').rstrip('/')
        self.timeout = timeout
        # Try multiple auth header styles (Atera docs vary by example)
        self.header_styles = [
            lambda key: {'X-API-KEY': key},
            lambda key: {'x-api-key': key},
            lambda key: {'Authorization': f'Bearer {key}'},
            lambda key: {'Authorization': key},
        ]

    def _request(self, method: str, path: str, params=None):
        url = urljoin(self.base_url + '/', path.lstrip('/'))
        last_exc = None
        for mk in self.header_styles:
            headers = mk(self.api_key)
            headers['Accept'] = 'application/json'
            try:
                r = requests.request(method, url, params=params, headers=headers, timeout=self.timeout)
                # If auth fails, try next header style
                if r.status_code in (401, 403):
                    last_exc = Exception(f"{r.status_code} Unauthorized/Forbidden with header style {headers}")
                    continue
                r.raise_for_status()
                return r.json()
            except requests.HTTPError as he:
                # Non-auth errors: raise
                if r.status_code not in (401, 403):
                    raise
                last_exc = he
            except Exception as e:
                last_exc = e
        # If all header styles failed
        raise last_exc or Exception('Falha de autenticação Atera')

    def get_agents(self, page=1, items_in_page=50):
        return self._request('GET', f'/api/v3/agents', params={'page': page, 'itemsInPage': items_in_page})

    def get_devices(self, page=1, items_in_page=50):
        return self._request('GET', f'/api/v3/devices', params={'page': page, 'itemsInPage': items_in_page})

    def get_agent_software(self, agent_id: int, page=1, items_in_page=100):
        # Different tenants expose software via different paths; try common ones
        candidates = [
            f'/api/v3/agents/{agent_id}/software',
            f'/api/v3/agents/{agent_id}/installed-applications',
            f'/api/v3/agents/{agent_id}/applications',
        ]
        last_exc = None
        for path in candidates:
            try:
                return self._request('GET', path, params={'page': page, 'itemsInPage': items_in_page})
            except Exception as e:
                last_exc = e
                continue
        # Fallback: some schemas include software in /devices
        # This returns empty if not found
        return {'result': [], 'page': 1, 'itemsInPage': 0, 'totalPages': 1}
