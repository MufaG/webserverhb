INTRANET - COLABORADORES (UPDATE 3 - CLEAN)

O QUE TRAZ:
- Blueprint Flask `colaboradores.py` com rotas:
  /colaboradores                -> página "Checklist de Onboarding" (Departamento -> Função)
  /colaboradores/funcs          -> API JSON com funções agrupadas por departamento (lê data/funcoes.json existente)
  /colaboradores/pdf            -> POST: gera PDF para download (ReportLab se disponível; senão TXT)
  /colaboradores/mailto         -> GET: abre link mailto: com os dados

- Templates:
  app/templates/colaboradores/preencher.html

- Dados base:
  data/checklists.json          -> Modelo base de checklist (não sobrescreve funcoes.json)

INSTALAÇÃO:
1) Copiar ficheiros:
   sudo cp -r _update_colab3_clean/app/blueprints/colaboradores.py /opt/farmodietica_intranet/app/blueprints/
   sudo cp -r _update_colab3_clean/app/templates/colaboradores /opt/farmodietica_intranet/app/templates/
   sudo cp -n _update_colab3_clean/data/checklists.json /opt/farmodietica_intranet/data/

2) Registar blueprint em /opt/farmodietica_intranet/app/__init__.py (se ainda não estiver):
   from app.blueprints.colaboradores import colab_bp
   app.register_blueprint(colab_bp)

3) Menu (base.html), só para ADMIN, antes do Dashboard:
   {% if session.get('role') == 'ADMIN' %}
   <li><a href="{{ url_for('colaboradores.view') }}">👥 Colaboradores</a></li>
   {% endif %}

4) Reiniciar:
   sudo systemctl restart intranet

PDF opcional:
   pip install reportlab
