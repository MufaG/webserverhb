
from __future__ import annotations
import os, io, json
from flask import Blueprint, render_template, request, jsonify, send_file, redirect, url_for, session, current_app
try:
    # login_required já existe no projeto base (core.py)
    from .core import login_required  # type: ignore
except Exception:
    # fallback no caso de estrutura diferente
    def login_required(f):
        return f

colab_bp = Blueprint("colaboradores", __name__, url_prefix="/colaboradores")

def _data_path(name: str) -> str:
    base = os.path.join(os.path.dirname(os.path.dirname(__file__)), "..", "data")
    return os.path.abspath(os.path.join(base, name))

def _role():
    return session.get("role") or session.get("user_role") or session.get("perfil")

def _is_admin() -> bool:
    return (_role() or "").upper() == "ADMIN"

def _load_funcoes() -> dict[str, list[str]]:
    fp = _data_path("funcoes.json")
    if not os.path.exists(fp):
        return {}
    with open(fp, "r", encoding="utf-8") as f:
        raw = json.load(f)

    result = {}
    # Lista de strings "Departamento - Função"
    if isinstance(raw, list) and all(isinstance(x, str) for x in raw):
        for s in raw:
            parts = s.split(" - ", 1)
            if len(parts) == 2:
                dep, func = parts
            else:
                dep, func = "Outros", parts[0]
            dep = (dep or "Outros").strip()
            func = (func or "Função").strip()
            result.setdefault(dep, []).append(func)

    # Lista de dicionários
    elif isinstance(raw, list) and all(isinstance(x, dict) for x in raw):
        for row in raw:
            dep = (row.get("departamento") or row.get("Departamento") or "Outros").strip()
            func = (row.get("nome") or row.get("Função") or row.get("funcao") or "Função").strip()
            result.setdefault(dep, []).append(func)

    # Dict agrupado
    elif isinstance(raw, dict):
        for dep, funs in raw.items():
            if isinstance(funs, dict):
                funs = list(funs.keys())
            result[dep] = [str(x).strip() for x in (funs or [])]

    # dedup + sort
    for k, v in result.items():
        result[k] = sorted(list(dict.fromkeys([x for x in v if x])))
    return dict(sorted(result.items(), key=lambda kv: kv[0].lower()))

@colab_bp.before_request
@login_required
def only_admin():
    if not _is_admin():
        return redirect(url_for("core.dashboard"))

@colab_bp.route("/", methods=["GET"])
def view():
    funcoes = _load_funcoes()
    return render_template("colaboradores/preencher.html", funcoes=funcoes)

@colab_bp.route("/api/funcoes", methods=["GET"])
def api_funcoes():
    return jsonify(_load_funcoes())

@colab_bp.route("/pdf", methods=["POST"])
def pdf():
    data = request.form.to_dict()
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfgen import canvas
        from reportlab.lib.units import cm
        buf = io.BytesIO()
        c = canvas.Canvas(buf, pagesize=A4)
        w, h = A4
        y = h - 2*cm
        c.setFont("Helvetica-Bold", 14); c.drawString(2*cm, y, "Checklist de Onboarding"); y -= 1*cm
        c.setFont("Helvetica", 11)
        for k, v in data.items():
            line = f"{k}: {v}"
            if y < 2*cm: c.showPage(); y = h - 2*cm; c.setFont("Helvetica", 11)
            c.drawString(2*cm, y, line); y -= 0.7*cm
        c.showPage(); c.save(); buf.seek(0)
        from datetime import datetime
        fname = f"onboarding_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        return send_file(buf, as_attachment=True, download_name=fname, mimetype="application/pdf")
    except Exception:
        # fallback para TXT
        s = io.StringIO()
        s.write("Checklist de Onboarding\n\n")
        for k, v in data.items():
            s.write(f"{k}: {v}\n")
        buf = io.BytesIO(s.getvalue().encode("utf-8"))
        from datetime import datetime
        fname = f"onboarding_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        return send_file(buf, as_attachment=True, download_name=fname, mimetype="text/plain; charset=utf-8")
