# Intranet TI · Farmodietica

Protótipo Flask com login e páginas base.

## Setup rápido (desenvolvimento)
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env  # edita SECRET_KEY / ADMIN_* 
python3 run.py
```

## Produção (Gunicorn + Nginx + Systemd)
Ver ficheiros em `deploy/`.
